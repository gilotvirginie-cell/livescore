export const config = {
                   matcher: '/:path*',
                 }
     
                 export function middleware(request) {
                   // Logique middleware vide ou personnalisée
                 }