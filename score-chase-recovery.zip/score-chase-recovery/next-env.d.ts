/// <reference types="next" />
/// <reference types="next/image-types/global" />

// NOTE: Ce fichier ne doit pas être modifié.